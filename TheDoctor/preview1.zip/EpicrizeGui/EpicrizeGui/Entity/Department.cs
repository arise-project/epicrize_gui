﻿/*
 * Created by SharpDevelop.
 * User: Eugene
 * Date: 17.01.2010
 * Time: 22:27
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace EpicrizeGui.Entity
{
	/// <summary>
	/// Description of Class1.
	/// </summary>
	public class Department : IEntity
	{
		public Department()
		{
		}
		
		public int Id {
			get;
			set;
		}
		
		public string DepartmentName
		{
			get;
			set;
		}
		
		public string DepartmentAddress
		{
			get;
			set;
		}
		
		public string Identifier
		{
			get;
			set;
		}
		
		public void Save()
		{
			throw new NotImplementedException();
		}
	}
}
