﻿/*
 * Created by SharpDevelop.
 * User: Eugene
 * Date: 15.01.2010
 * Time: 16:55
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace SimpleTester
{
	/// <summary>
	/// Description of __Epicrize.
	/// </summary>
	public class Epicrize
	{
		public Epicrize()
		{
		}
		
		public DateTime Date
		{
			get;
			set;
		}
		
		public string Diagnose
		{
			get;
			set;
		}
	}
}
