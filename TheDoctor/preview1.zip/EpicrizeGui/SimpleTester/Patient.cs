﻿/*
 * Created by SharpDevelop.
 * User: Eugene
 * Date: 15.01.2010
 * Time: 0:32
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace SimpleTester
{
	/// <summary>
	/// Description of Patient.
	/// </summary>
	public class Patient
	{
		public Patient()
		{
		}
		
		public string FirstName
		{
			get;
			set;
		}
		
		public string LastName
		{
			get;
			set;
		}
	}
}
