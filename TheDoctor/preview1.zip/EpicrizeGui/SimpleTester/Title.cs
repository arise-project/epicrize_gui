﻿/*
 * Created by SharpDevelop.
 * User: Eugene
 * Date: 15.01.2010
 * Time: 17:33
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace SimpleTester
{
	/// <summary>
	/// Description of Class1.
	/// </summary>
	public class Title
	{
		public Title()
		{
		}
		
		public string Caption
		{
			get;
			set;
		}
	}
}
